import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class page3 extends HttpServlet {
	private int hitcts;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		HttpSession obj = req.getSession(false);
		hitcts = (int)obj.getAttribute("htc");
		hitcts = hitcts + 1;
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<p>Hit Count: "+hitcts+"</p>");
		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");
	}
}
