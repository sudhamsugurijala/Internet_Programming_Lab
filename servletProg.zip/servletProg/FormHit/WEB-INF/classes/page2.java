import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class page2 extends HttpServlet {
	private int hitcts;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String n = req.getParameter("htc");
		hitcts = Integer.parseInt(n);
		hitcts = hitcts + 1;
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<p>Hit Count: "+hitcts+"</p>");
		pw.println("<form action = 'hitC3' method = 'get'>");
		pw.println("<input type = 'hidden' name = 'htc' value = "+ hitcts+">");
		pw.println("<input type = 'submit' value = 'submit'>");
		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");
	}
}
