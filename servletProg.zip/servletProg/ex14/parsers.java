import org.w3c.dom.*;   //for document builder factory
import javax.xml.parsers.*; // for classes like DBF and DB(Document Builder Class)
import java.io.*;
import java.util.Scanner;

public class parsers {
 public static void main(String[] args){
  try{
	DocumentBuilderFactory dbf  = DocumentBuilderFactory.newInstance();
	DocumentBuilder db = dbf.newDocumentBuilder();

	Document doc = db.parse("example.xml");
	Element root = doc.getDocumentElement();
	System.out.println("The Root is -------> "+root.getNodeName());
	NodeList nList = doc.getElementsByTagName("student");
       	System.out.println("----------------------------");
	Scanner in = new Scanner(System.in);
	System.out.print("Enter roll no of a student:");
	int roll = in.nextInt();
        for (int temp = 0; temp < nList.getLength(); temp++) {
		Node nNode = nList.item(temp);
            	if (nNode.getNodeType() == Node.ELEMENT_NODE) {
               		Element eElement = (Element) nNode;
			if(roll == Integer.parseInt(eElement.getAttribute("rollno"))){
				System.out.println("roll no : " + eElement.getAttribute("rollno"));
			        System.out.println("Name : " + eElement.getElementsByTagName("name").item(0).getTextContent());
			        System.out.println("address : "+ eElement.getElementsByTagName("address").item(0).getTextContent());
			        System.out.println("Mobile : "+eElement.getElementsByTagName("mobile").item(0).getTextContent());
			        System.out.println("Email : "+ eElement.getElementsByTagName("email").item(0).getTextContent());
			}
            	}
	}
  } catch(Exception e){
	System.out.println(e);
  }
 }
}
