import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class data extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		Connection con;
		PreparedStatement ps;
		final String DB_URL = "jdbc:mysql://localhost:3306/gd";
		final String USR = "root";
		final String PASS = "ssn";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL, USR, PASS);
			System.out.println(" Connection Established");
			try {
				String name = req.getParameter("name");
				int roll = Integer.parseInt(req.getParameter("roll"));
				String sql = "update student set name=? where rollno=?)";
				ps = con.prepareStatement(sql);
				ps.setString(1, name);
				ps.setString(2, roll);
				ps.execute();
				pw.println(" Update Successful");
			} catch (Exception e) {
				pw.println(" Internal Error");
			}
		} catch (Exception e) {
			pw.println(e.getMessage());
		}
		pw.println("</body>");
		pw.println("</html>");
	}
}
