import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class data extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		Connection con;
		Statement stmt;
		final String DB_URL = "jdbc:mysql://localhost:3306/gd";
		final String USR = "root";
		final String PASS = "ssn";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL, USR, PASS);
			System.out.println(" Connection Established");
			try {
				stmt = con.createStatement();
				String sql = "select * from student";
				ResultSet rs = stmt.executeQuery(sql);
				while (rs.next()) {
					int id = rs.getInt("id");
					String name = rs.getString("name");
					pw.println("<p>"+id+"</p>");
					pw.println("<p>"+name+"</p><br><br>");
				}
			} catch (Exception e) {
				pw.println(" Internal Error");
			}
		} catch (Exception e) {
			pw.println(e.getMessage());
		}
		pw.println("</body>");
		pw.println("</html>");
	}
}
