import java.io.*;
import javax.Servlet.*;
import javax.Servlet.http.*;

public class hello extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
	}
	public static void main() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:3306/","","");
			
		} catch(Exception e) {
			System.out.println(" eRrOr");
		}
	}
}