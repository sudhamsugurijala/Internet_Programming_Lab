import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class hitCount extends HttpServlet {
	private int hitcts;
	public void init() throws ServletException{
		hitcts = 1;
	}
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String name = req.getParameter("name");
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<p>Hello! "+name+"</p><br>");
		pw.println("<p>Hit Count: "+hitcts+"</p>");
		HttpSession obj = req.getSession(true);
		obj.setAttribute("htc",hitcts);
		pw.println("<form action = 'hitC2' method = 'get'>");
		pw.println("<input type = 'submit' value = 'submit'>");
		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");
	}
}
