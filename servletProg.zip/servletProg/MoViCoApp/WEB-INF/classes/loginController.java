import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import Bean.userBean;
import DAO.userDAO;

public class loginController extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String uname = req.getParameter("t1");
		String pass = req.getParameter("t2");
		userBean usr = new userBean();
		usr.setU(uname);
		usr.setP(pass);
		userDAO dao = new userDAO();
		int r = dao.auth(usr);
		if(r==1) {
			req.getRequestDispatcher("success.jsp").forward(req,res);
		}
		else {
			req.getRequestDispatcher("failure.jsp").forward(req,res);
		}
	}
}
