package Bean;
public class userBean {
	private String n,p;
	public void setU(String username) {
		this.n = username;
	}
	public void setP(String password) {
		this.p = password;
	}
	public String getU() {
		return n;
	}
	public String getP() {
		return p;
	}
}
