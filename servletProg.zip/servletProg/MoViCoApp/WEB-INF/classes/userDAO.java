package DAO;

import Bean.userBean;
import java.io.*;
import java.sql.*;

public class userDAO {
	public int auth(userBean l) {
		final String DB_URL = "jdbc:mysql://localhost:3306/gd";
		final String USR = "root";
		final String PASS = "ssn";
		String user = l.getU();
		String pass = l.getP();
		try {
			Connection con;
			Statement stmt;
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL, USR, PASS);
			stmt = con.createStatement();
			String sql = "select * from users";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				if(user.equals(rs.getString("duser"))) {
					if(pass.equals(rs.getString("dpass"))) {
						return 1;
					}
					else {
						return 0;					
					}
				}
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}
}
