import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class insert extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		Connection con;
		PreparedStatement ps;
		final String DB_URL = "jdbc:mysql://localhost:3306/gd";
		final String USR = "root";
		final String PASS = "ssn";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL, USR, PASS);
			System.out.println(" Connection Established");
			try {
				String name = req.getParameter("name");
				String roll = req.getParameter("id");
				String sql = "insert into student values(?,?)";
				ps = con.prepareStatement(sql);
				ps.setString(1, roll);
				ps.setString(2, name);
				ps.execute();
				String m1 = req.getParameter("mark1");
				String m2 = req.getParameter("mark2");
				String m3 = req.getParameter("mark3");
				String m4 = req.getParameter("mark4");
				String m5 = req.getParameter("mark5");
				sql = "insert into marks values(?,?,?,?,?,?)";
				ps = con.prepareStatement(sql);
				ps.setString(1, roll);
				ps.setString(2, m1);
				ps.setString(3, m2);
				ps.setString(4, m3);
				ps.setString(5, m4);
				ps.setString(6, m5);
				
				ps.execute();
				pw.println(" Insert Successful");
				pw.println("<br><a href='index.html'>Go back</a>");
			} catch (Exception e) {
				pw.println(" Internal Error");
				pw.println("<br><a href='index.html'>Go back</a>");
			}
		} catch (Exception e) {
			pw.println(e.getMessage());
		}
		pw.println("</body>");
		pw.println("</html>");
	}
}
