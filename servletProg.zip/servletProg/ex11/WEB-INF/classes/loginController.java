import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import Bean.userBean;
import DAO.userDAO;

public class loginController extends HttpServlet {
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		String uname = req.getParameter("t1");

		userBean usr = new userBean();
		usr.setU(uname);

		userDAO dao = new userDAO();
		int r = dao.auth(usr);
		if(r==1) {
			req.getRequestDispatcher("read.jsp").forward(req,res);
		}
		else {
			req.getRequestDispatcher("failure.jsp").forward(req,res);
		}
	}
}
