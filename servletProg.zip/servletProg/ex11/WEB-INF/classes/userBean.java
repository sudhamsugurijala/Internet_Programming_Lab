package Bean;
public class userBean {
	private String n;
	public void setU(String username) {
		this.n = username;
	}
	
	public String getU() {
		return n;
	}
}