package DAO;

import java.io.*;
import java.sql.*;
import Bean.userBean;

public class userDAO {
	public int auth(userBean l) {
		final String DB_URL = "jdbc:mysql://localhost:3306/gd";
		final String USR = "root";
		final String PASS = "ssn";
		String user = l.getU();
		try {
			Connection con;
			Statement stmt;
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DB_URL, USR, PASS);
			stmt = con.createStatement();
			String sql = "select * from student";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()) {
				if(user.equals(rs.getString("id"))) {
						return 1;
				}
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}
}
