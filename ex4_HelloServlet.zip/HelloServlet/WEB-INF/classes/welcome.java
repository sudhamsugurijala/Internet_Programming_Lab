import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class welcome extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		
		String name = req.getParameter("uname");
		
		out.println("<html>");
		out.println("<body>");
		out.println("<p> Welcome </p><br>");
		out.println("<p>"+name+"</p>");
		out.println("<body>");
		out.println("</html>");
	}
}
