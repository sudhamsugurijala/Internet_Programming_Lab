import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class mulServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		int num1 = Integer.parseInt(req.getParameter("addnum1"));
		int num2 = Integer.parseInt(req.getParameter("addnum2"));
		int result = num1 * num2;
		
		out.println("<html>");
		out.println("<body>");
		out.println("<div style='align-text:center;'>");
		out.println("<p>"+result+"</p>");
		out.println("<div>");
		out.println("<body>");
		out.println("</html>");
	}
}
