import java.sql.*;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author csec4170
 */
@WebService(serviceName = "OpinionWebService")
public class OpinionWebService {
    /**
     * This is a sample web service operation
     */
    /**
     * Web service operation
     */
    @WebMethod(operationName = "opinion")
    public String opinion(@WebParam(name = "name") String name) {
        //TODO write your implementation code here:
        String quality = "";
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/gd", "root", "ssn");
            Statement stmt;
            String sql = "select quality from product where name='"+name+"'";
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                quality += rs.getString("quality");
            }
        } catch(Exception e) {
            System.out.println("Error");
        }
        return quality;
    }

}
