var op = "";
function validateName() {
	var nameDef = new RegExp('^\\w+$');
	var nameVar = document.getElementById("nameInput").value;
 	if (nameDef.test(nameVar)) {
 		op = op + " Name: " + nameVar + "\n";
 	 	alert(" Valid Input \n" + op);
 	}
 	else {
 	 	alert(" Invalid Input ");

 	}
}

function validatePh() {
	var phDef = new RegExp('^\\d{10}$');
	var phVar = document.getElementById("phInput").value;
	if (phDef.test(phVar)) {
		op = op + " Phone: " + phVar + "\n";
		alert(" Valid Input \n" + op);
	}
	else {
		alert(" Invalid Input ");
	}
}

function validateAge() {
	var ageDef = new RegExp('^\\d{3}$');
	var ageVar = document.getElementById("ageInput").value;
	if (ageDef.test(ageVar)) {
		/*if (ageVar < 110) {*/
			op = op + " Age: " + ageVar + "\n";
			alert(" Valid Input \n" + op);
		/*}
		else
			alert(" Value too Unreal ");*/
	}
	else {
		alert(" Invalid Input 1000 ");
	}
}

function validateMail() {
	var mailDef = new RegExp('^\\w+\\@\\w+\\.\\w+$');
	var mailVar = document.getElementById("mailInput").value;
	if (mailDef.test(mailVar)) {
		op = op + " Mail: " + mailVar + "\n";
		alert(" Valid Input \n" + op);
	}
	else {
		alert(" Invalid Input ");
	}
}

function validateDate() {
	var dateDef = new RegExp('^\\d{2}\\/\\d{2}\\/\\d{4}$');
	var dateVar = document.getElementById("dateInput").value;
	if (dateDef.test(dateVar)) {
		op = op + " DOB: " + dateVar + "\n";
		alert(" Valid Input \n" + op);
	}
	else {
		alert(" Invalid Input ");
	}
}

function submitDet() {
	alert(" Details \n" + op);
}
