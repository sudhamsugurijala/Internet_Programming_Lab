var op = "";
function validateName() {
	var nameDef = /^[a-zA-Z]+$/;
	var nameVar = document.getElementById("nameInput").value;
 	if (nameDef.test(nameVar)) {
 		op = op + " Name: " + nameVar + "\n";
 	 	alert(" Valid Input \n" + op);
 	 	return true;
 	} else {
 	 	alert(" Invalid Input ");
 	}
 	return false;
}

function validateAge() {
	var ageDef = new RegExp('^\\d{2,3}$');
	var ageVar = document.getElementById("ageInput").value;
	if (ageDef.test(ageVar)) {
		if (ageVar < 110) {
			op = op + " Age: " + ageVar + "\n";
			alert(" Valid Input \n" + op);
			return true;
		} else {
				alert(" Value too Unreal ");
			}
	} else {
		alert(" Invalid Input ");
	}
	return false;
}

function validatePh() {
	var phDef = new RegExp('^\\d{10}$');
	var phVar = document.getElementById("phInput").value;
	if (phDef.test(phVar)) {
		op = op + " Phone: " + phVar + "\n";
		alert(" Valid Input \n" + op);
		return true;
	} else {
		alert(" Invalid Input ");
	}
	return false;
}


function validateMail() {
	var mailDef = new RegExp('^\\w+\\@\\w+\\.\\w+$');
	var mailVar = document.getElementById("mailInput").value;
	if (mailDef.test(mailVar)) {
		op = op + " Mail: " + mailVar + "\n";
		alert(" Valid Input \n" + op);
		return true;
	} else {
		alert(" Invalid Input ");
	}
	return false;
}

function validateDate() {
	var dateDef = /^(0[1-9]|[12][0-9]|3[01])[/](0[1-9]|1[012])[/](19|20|21)\d\d$/;
	var dateVar = document.getElementById("dateInput").value;
	if (dateDef.test(dateVar)) {
		var parts = dateVar.split("/");
    	var day = parseInt(parts[0], 10);
    	var month = parseInt(parts[1], 10);
    	var year = parseInt(parts[2], 10);

    	var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

    // Adjust for leap years
   	 	if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
   	     	monthLength[1] = 29;

    // Check the range of the day
    	if(day > 0 && day <= monthLength[month - 1]){
    		op = op + " DOB: " + dateVar + "\n";
			alert(" Valid Input \n" + op);
			return true;
    	} else {
    		alert(" Invalid days for the month ");
    	}
	} else {
		alert(" Invalid Input ");
	}
	return false;
}

function submitDet() {
	var addrVar = document.getElementById("addrInput").value;
	op = op + " Address: " + addrVar + "\n";
	var gender = document.getElementsByName("gender");
	var i;
	for(i = 0; i < gender.length; i++) { 
        if(gender[i].checked) {
			op = op + "Gender: " + gender[i].value + "\n";
		}
	}
	var purpose = document.getElementsByName("purpose");
	op = op + "Purpose: ";
	for(i = 0; i < purpose.length; i++) { 
        if(purpose[i].checked) {
        	op = op + purpose[i].value + " ";
		}
	}
	op = op + "\n";
	alert(" Details \n" + op);
}
