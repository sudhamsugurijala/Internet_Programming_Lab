<html>
<head>
<title>helloPHP</title>
</head>
<body>

<form action="display.php" method="get">
 <input type="submit" value="Display"> <br><br>
</form>
<form action="create.php" method="get">
 <input type="text" name="name" placeholder="username"><br>
 <input type="text" name="number" placeholder="number"><br>
 <input type="text" name="mail" placeholder="mail"><br>
 <input type="text" name="addr" placeholder="address"><br>
 <input type="text" name="age" placeholder="age"><br>
 <input type="text" name="date" placeholder="date"><br><br>
 <input type="submit" value="Insert">
</form>

<form action="update.php" method="get">
 <input type="text" name="name" placeholder="username"><br>
 <input type="text" name="number" placeholder="number"><br>
 <input type="text" name="mail" placeholder="mail"><br>
 <input type="text" name="addr" placeholder="address"><br>
 <input type="text" name="age" placeholder="age"><br>
 <input type="text" name="date" placeholder="date"><br><br>
 <input type="submit" value="Update">
</form>

<form action="delete.php" method="get">
 <input type="text" name="name" placeholder="username"><br><br>
 <input type="submit" value="delete">
</form>

</body>
</html>

