<?php
	$con = new mysqli("localhost:3306","root","ssn","gd");
	if($con->connect_error)
		echo "Connection Error";
	else
		echo "Connection Established"."<br><br>";

	$sql = "select * from usersphp";
	$res = $con->query($sql);
	if($res->num_rows > 0) {
		while($row = $res->fetch_assoc()) {
			echo $row["duser"]." ";
			echo $row["dnum"]." ";
			echo $row["dmail"]." ";
			echo $row["dadd"]." ";
			echo $row["dage"]." ";
			echo $row["ddate"]."<br>";
		}
	}
	echo "<br><br>";

	$sql = "insert into usersphp values(?,?,?,?,?,?)";
	$stmt = $con->prepare($sql);
	mysqli_stmt_bind_param($stmt, "ssssss", $name, $num, $mail, $addr, $age, $date);
	$name = $_GET["name"];
	$num = $_GET["number"];
	$mail = $_GET["mail"];
	$addr = $_GET["addr"];
	$age = $_GET["age"];
	$date = $_GET["date"];
	
	$regexName = '/^[a-zA-Z]+$/'; 
	$regexNum = '/^[0-9]{10}$/'; 
	$regexMail = '/^[a-z][a-zA-Z0-9]+\@[a-zA-Z]+\.[a-zA-Z]+$/';
	$regexAge = '/^[0-9]{2}$/';

	if(preg_match($regexName, $name)) {
		if(preg_match($regexNum, $num)) {
			if(preg_match($regexMail, $mail)) {
				if(preg_match($regexAge, $age)) {
					mysqli_stmt_execute($stmt);
					echo "Details valid, transaction done.";
				}
				else {
					echo "Age invalid.";
				}
			}
			else {
				echo "Mail Invalid, transaction aborted.";		
			}
		}
		else {
			echo "Number Invalid, transaction aborted.";
		}
	} 
	else { 
    		echo("Only letters allowed in name string");  
	}

	echo "<br><br>";

	$sql = "select * from usersphp";
	$res = $con->query($sql);
	if($res->num_rows > 0) {
		while($row = $res->fetch_assoc()) {
			echo $row["duser"]." ";
			echo $row["dnum"]." ";
			echo $row["dmail"]." ";
			echo $row["dadd"]." ";
			echo $row["dage"]." ";
			echo $row["ddate"]."<br>";
		}
	}
?>
