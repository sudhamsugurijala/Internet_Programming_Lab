<?php
	$con = new mysqli("localhost:3306","root","ssn","gd");
	if($con->connect_error)
		echo "Connection Error";
	else
		echo "Connection Established"."<br><br>";

	$sql = "select * from usersphp";
	$res = $con->query($sql);
	if($res->num_rows > 0) {
		while($row = $res->fetch_assoc()) {
			echo $row["duser"]." ";
			echo $row["dnum"]." ";
			echo $row["dmail"]." ";
			echo $row["dadd"]." ";
			echo $row["dage"]." ";
			echo $row["ddate"]."<br>";
		}
	}
	echo "<br><br>";

	$sql = "delete from usersphp where duser = ?";
	$stmt = $con->prepare($sql);
	mysqli_stmt_bind_param($stmt, "s", $name);
	$name = $_GET["name"];

	mysqli_stmt_execute($stmt);
	echo " Delete successful.";
	echo "<br><br>";

	$sql = "select * from usersphp";
	$res = $con->query($sql);
	if($res->num_rows > 0) {
		while($row = $res->fetch_assoc()) {
			echo $row["duser"]." ";
			echo $row["dnum"]." ";
			echo $row["dmail"]." ";
			echo $row["dadd"]." ";
			echo $row["dage"]." ";
			echo $row["ddate"]."<br>";
		}
	}
?>
