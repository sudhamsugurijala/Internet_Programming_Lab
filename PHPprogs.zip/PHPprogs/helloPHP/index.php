<html>
<head>
<title>helloPHP</title>
</head>
<body>
<form action="hello.php" method="get">
 <input type="text" placeholder="name" name="name"/>
 <input type="submit" value="say Hello">
</form>
</body>
</html>

