<?php
 $name = $_GET["name"];
 echo "Hello ".$name."<br>";
?>
